/**
 * NAME Namespacing
 */
var NAME = NAME || {};